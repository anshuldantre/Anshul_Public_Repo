console.log("page loaded...");

function playTheVideo(element) {
    element.play();
}

function stopTheVideo(element) {
    element.pause();
}